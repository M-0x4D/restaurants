@extends('admin.layouts.main')

@section('content')


<div class="content-inner mt-5 py-0">

    @include('admin.restaurants.partials.rowfour')
    @include('admin.restaurants.partials.rowfive')
    @include('admin.restaurants.partials.rowone')
    @include('admin.restaurants.partials.rowtwo')
    @include('admin.restaurants.partials.rowthree')


</div>



@endsection


